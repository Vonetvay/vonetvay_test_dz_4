using UnityEngine;

public static class ToDegreesConverter
{
    private const float s_MAX_DEGREES = 360;
    private const float s_MAX_RADIANS = Mathf.PI * 2;

    public static float ConvertToDegrees(float angle) => angle / (s_MAX_DEGREES / s_MAX_RADIANS);
}
