using TMPro;
using UnityEngine;

public class DisplayCoinCounter : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI _counter;
    private AudioSource _audioSource;

    private Animator _animator;

    private void Awake()
    {
        _animator = GetComponent<Animator>();
        _audioSource = GetComponent<AudioSource>();
    }

    private void OnEnable()
    {
        CoinCounter.onCoinPunOn += CounterUpdate;
    }

    private void OnDisable()
    {
        CoinCounter.onCoinPunOn -= CounterUpdate;
    }

    private void CounterUpdate() 
    {
        _counter.text = CoinCounter.GetCoins().ToString();
        _animator.SetTrigger("CoinPutOn");
        _audioSource.Play();
    }
}
