using UnityEngine;

public class BoxDestroyer : MonoBehaviour
{
    [SerializeField] private GameObject _coin;
    [SerializeField] private GameObject _chip;
    [SerializeField] private int _chipCount;
    [SerializeField] private GameObject _boxDestroySound;

    public void BeginDestroy() 
    {
        Instantiate(_boxDestroySound, transform.position, Quaternion.identity);
        for (int i = 0; i < _chipCount; i++) 
        { 
            GameObject _obj = Instantiate(_chip, transform.position, Quaternion.identity);
            _obj.GetComponent<Rigidbody>().AddForce(new Vector3(Random.Range(-1, 1), Random.Range(-1, 1), Random.Range(-1, 1)) * 1000);
        }
        Instantiate(_coin, transform.position, Quaternion.Euler(90f, 0f, 0f));
        Destroy(gameObject);
    }
}
