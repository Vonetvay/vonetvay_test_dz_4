using UnityEngine;

public class CoinPickup : MonoBehaviour
{
    private FlyingCoinSpawner _flyingCoinSpawner;
    private ForwardRayCasting _forwardRayCasting;

    private void Awake()
    {
        _forwardRayCasting = FindObjectOfType<ForwardRayCasting>();
        _flyingCoinSpawner = FindObjectOfType<FlyingCoinSpawner>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<Coin>()) 
        {
            _flyingCoinSpawner.Spawn((transform.position - _forwardRayCasting.GetForwardRayCastPoint()));
            Destroy(other.gameObject);
        }
    }
}
