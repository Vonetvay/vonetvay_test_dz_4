using UnityEngine;

public class FlyingCoin : MonoBehaviour
{
    [SerializeField] private AnimationCurve _derivativeSpeed;
    [SerializeField] private float _moveTime;
    private float _curveSum;
    private float _delta;

    private Transform _target;
    private float _targetDistance;

    private void Awake()
    {
        for (float i = 0; i < 1; i += .01f) 
        {
            _curveSum += _derivativeSpeed.Evaluate(i);
        }
    }

    public void SetTarget(Transform _transform) 
    {
        _target = _transform;
        _targetDistance = Mathf.Sqrt(Mathf.Pow(Mathf.Sqrt(Mathf.Pow(_target.position.x - transform.position.x, 2)
            + Mathf.Pow(_target.position.y - transform.position.y, 2)), 2) + Mathf.Pow(_target.position.z - transform.position.z, 2));
        InvokeRepeating("Move", 0f, _moveTime / 100f);
    }
    
    private void Move()
    {
        transform.position = Vector3.MoveTowards(transform.position, _target.position, (100f / _curveSum) * _targetDistance * .01f * _derivativeSpeed.Evaluate(_delta));
        _delta += 0.01f;
        if (_delta > 1) 
        {
            CancelInvoke();
            CoinCounter.PutOnCoin();
            Destroy(gameObject);
        }
    }
}
