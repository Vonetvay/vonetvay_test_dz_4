using UnityEngine;

public class FlyingCoinSpawner : MonoBehaviour
{
    [SerializeField] private GameObject _flyingCoinPrefab;
    [SerializeField] private Transform _counterPoint;

    public void Spawn(Vector3 _position) 
    {
        GameObject _obj = Instantiate(_flyingCoinPrefab, transform);
        _obj.transform.position += _position;
        _obj.GetComponent<FlyingCoin>().SetTarget(_counterPoint);
    }
}
