using UnityEngine;

public class DisplayWinMessage : MonoBehaviour
{
    [SerializeField] private GameObject _winMessage;

    private void OnEnable()
    {
        CoinCounter.onCoinPunOn += Display;
    }

    private void OnDisable()
    {
        CoinCounter.onCoinPunOn -= Display;
    }

    public void Display() 
    {
        if (CoinCounter.GetCoins() >= 4)
        {
            _winMessage.SetActive(true);
        }
    }
}
