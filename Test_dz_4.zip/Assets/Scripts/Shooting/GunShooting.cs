using UnityEngine;

[RequireComponent(typeof(BulletSpawner))]
public class GunShooting : MonoBehaviour
{
    [SerializeField] float _shootIntervalTime;

    private BulletSpawner _bulletSpawner;
    private Animator _animator;

    private AudioSource _audioSource;

    private void Awake()
    {
        _bulletSpawner = GetComponent<BulletSpawner>();
        _animator = GetComponent<Animator>();
        _audioSource = GetComponent<AudioSource>();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(1)) 
        {
            InvokeRepeating("Shoot", 0f, .2f);
            _audioSource.Play();
        }
        else if (Input.GetMouseButtonUp(1)) 
        {
            CancelInvoke();
            _audioSource.Stop();
        }
    }

    private void Shoot() 
    {
        _bulletSpawner.Spawn();
        _animator.SetTrigger("Shoot");
    }
}
