using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    [SerializeField] private Transform _camera;
    [SerializeField] private Transform _spawnPoint;
    [SerializeField] private Bullet _bullet;

    public void Spawn() 
    {
        Instantiate(_bullet, _spawnPoint.position, _camera.rotation);
    }
}
