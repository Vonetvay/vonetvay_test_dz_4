using System;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] private float _lifeTime;
    [SerializeField] private float _speed;

    private Rigidbody _rb;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        Invoke("Death", _lifeTime);
    }

    

    private void FixedUpdate()
    {
        _rb.velocity = new Vector3(
            Mathf.Sin(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.y)),
            -Mathf.Sin(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.x)),
            Mathf.Cos(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.y))
            ) * _speed;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<BoxDestroyer>())
        {
            collision.gameObject.GetComponent<BoxDestroyer>().BeginDestroy();
        }
        else if (collision.gameObject.GetComponent<EnemyDeath>()) 
        {
            collision.gameObject.GetComponent<EnemyDeath>().Death();
        }
        Death();
        CancelInvoke();
    }

    private void Death() 
    {
        Destroy(gameObject);
    }
}
