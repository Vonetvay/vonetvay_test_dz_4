using UnityEngine;
using UnityEngine.AI;

public class EnemyMovement : MonoBehaviour
{
    private Transform _target;
    private NavMeshAgent _agent;

    private void Awake()
    {
        _agent = GetComponent<NavMeshAgent>();
        _target = FindObjectOfType<PlayerMovement>().transform;
    }

    private void Update()
    {
        _agent.SetDestination(_target.position);
    }
}
