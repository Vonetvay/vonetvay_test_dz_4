using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private Transform[] _spawnPoints;
    [SerializeField] private GameObject _enemy;

    private void Awake()
    {
        InvokeRepeating("Spawn", 0f, 5f);
    }

    private void Spawn() 
    {
        foreach(Transform t in _spawnPoints) 
        {
            Instantiate(_enemy, t.position, Quaternion.identity);
        }
    }
}
