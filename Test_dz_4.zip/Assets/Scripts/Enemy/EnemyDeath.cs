using UnityEngine;
using UnityEngine.AI;

public class EnemyDeath : MonoBehaviour
{
    [SerializeField] private GameObject _drop;
    private Animator _animator;
    private AudioSource _audioSource;

    private void Awake()
    {
        _animator = GetComponent<Animator>();
        _audioSource = GetComponent<AudioSource>();
    }

    public void Death() 
    {
        _audioSource.Play();
        _animator.SetTrigger("Death");
        GetComponent<Collider>().enabled = false;
        GetComponent<NavMeshAgent>().enabled = false;
        GetComponent<EnemyMovement>().enabled = false;
        Invoke("DestroyBody", 4.26f);
    }

    public void DestroyBody() 
    {
        Instantiate(_drop, transform.position + new Vector3(0f, 1.5f, 0f), Quaternion.Euler(90f, 0f, 0f));
        Destroy(gameObject);
    }
}
