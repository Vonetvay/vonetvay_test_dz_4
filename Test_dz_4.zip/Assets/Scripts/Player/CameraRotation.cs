using UnityEngine;

public class CameraRotation : MonoBehaviour
{
    [SerializeField] private PlayerMovement _playerMovement;
    [SerializeField] private float _mouseSensitivity;
    [SerializeField] private Vector2 _cameraYAngleInterval;

    private Vector2 _mouseAxes;
    private float _xRotation;

    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void LateUpdate()
    {
        _mouseAxes.x = Input.GetAxis("Mouse X");
        _mouseAxes.y = Input.GetAxis("Mouse Y");

        _xRotation -= _mouseAxes.y * _mouseSensitivity;
        _xRotation = Mathf.Clamp(_xRotation, _cameraYAngleInterval.x, _cameraYAngleInterval.y);

        transform.localRotation = Quaternion.Euler(new Vector3(_xRotation, 0f, 0f));
        _playerMovement.transform.Rotate(new Vector3(0f, _mouseAxes.x * _mouseSensitivity, 0f));
    }
}
