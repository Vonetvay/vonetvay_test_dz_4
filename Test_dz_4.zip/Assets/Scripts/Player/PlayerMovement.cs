using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PlayerMovement : MonoBehaviour
{
    [Header("Walking")]
    [SerializeField] private float _speed;

    [Header("Sprinting")]
    [SerializeField] private KeyCode _sprintKey;
    [SerializeField] private float _speedMultiplayer;

    private Vector3 _moveDirection;

    private Rigidbody _rb;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(_sprintKey))
        {
            _speed *= _speedMultiplayer;
        }
        else if (Input.GetKeyUp(_sprintKey))
        {
            _speed /= _speedMultiplayer;
        }
    }

    private void FixedUpdate()
    {
        _moveDirection.x = Input.GetAxis("Horizontal");
        _moveDirection.z = Input.GetAxis("Vertical");

        _rb.velocity = new Vector3(
            (Mathf.Sin(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.y)) * _moveDirection.z +
            Mathf.Cos(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.y)) * _moveDirection.x) * _speed,
            _rb.velocity.y,
            (Mathf.Sin(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.y + 90f)) * _moveDirection.z +
            Mathf.Cos(ToDegreesConverter.ConvertToDegrees(transform.eulerAngles.y + 90f)) * _moveDirection.x) * _speed
            );
    }
}