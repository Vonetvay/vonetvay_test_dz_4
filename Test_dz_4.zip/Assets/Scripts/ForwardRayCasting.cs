using UnityEngine;

public class ForwardRayCasting : MonoBehaviour
{
    [SerializeField] private float _distance;

    public float GetDistance() => _distance;

    private void Update()
    {
        Debug.DrawRay(transform.position, transform.forward * _distance, Color.red);
    }

    public Vector3 GetForwardRayCastPoint() => new Ray(transform.position, Vector3.forward).GetPoint(_distance);
}
