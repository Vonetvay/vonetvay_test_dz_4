using System;

public static class CoinCounter
{
    private static int s_coins;
    public static Action onCoinPunOn;
    
    public static int GetCoins() => s_coins;

    public static void PutOnCoin() 
    {
        s_coins++;
        onCoinPunOn?.Invoke();
    }
}
